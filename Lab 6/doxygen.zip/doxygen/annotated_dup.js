var annotated_dup =
[
    [ "APP_LETIMER_PWM_TypeDef", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def" ],
    [ "BLE_CIRCULAR_BUF", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f" ],
    [ "CIRC_TEST_STRUCT", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t" ],
    [ "I2C_OPEN_STRUCT", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html", "struct_i2_c___o_p_e_n___s_t_r_u_c_t" ],
    [ "I2C_STATE_MACHINE_STRUCT", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t" ],
    [ "LEUART_OPEN_STRUCT", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t" ],
    [ "LEUART_STATE_MACHINE", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e.html", "struct_l_e_u_a_r_t___s_t_a_t_e___m_a_c_h_i_n_e" ]
];