var struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t =
[
    [ "cmd", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#a4d43e8212bdc9dbee866506f04effcea", null ],
    [ "data", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#aa1cf91039f621340f15bcd4c95f582ef", null ],
    [ "i2c", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#a1339bae9a0e94d6488c45da78d312219", null ],
    [ "I2c_address", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#ac801853b81fe07448742811d0785a54d", null ],
    [ "I2C_reg_address", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#a7bb50352a0f4a01a76d76dbcd957f852", null ],
    [ "read_cb", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#ab1162f092df970ded4a32539803e22d0", null ],
    [ "size", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "states", "struct_i2_c___s_t_a_t_e___m_a_c_h_i_n_e___s_t_r_u_c_t.html#a091c81214e52825df15b5801f6a5fce2", null ]
];