var struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def =
[
    [ "active_period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a1f35095c80d0db53cae171e4e89d947f", null ],
    [ "comp0_cb", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a227a83fbdc280282c4820e9ce98c6ed9", null ],
    [ "comp0_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ad680c5351fec9189d3ad2dce4980ee2f", null ],
    [ "comp1_cb", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#aab7712a06d9cf0da64db57a39cd1e1a5", null ],
    [ "comp1_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a3b39f0f5b0ef484941e193598e1e2679", null ],
    [ "debugRun", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a95936f85c6ab1a7f43f02f15f172f1db", null ],
    [ "enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "out_pin_0_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a282598b3f0c3b0995d10b02906545832", null ],
    [ "out_pin_1_en", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#af699d0977554fdb7ace801a05b12655e", null ],
    [ "out_pin_route0", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ad231c74a05a5a201e70e6dc49f3a45ea", null ],
    [ "out_pin_route1", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#adef2082a8109a6519ed8641b62a250e1", null ],
    [ "period", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#ae08ac1ff9a62c213c5768ca3a538e546", null ],
    [ "uf_cb", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#a5de75dd7fce8f5a7f27579fda8808439", null ],
    [ "uf_irq_enable", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html#af104f924dc7950be2f072f3f923d636a", null ]
];