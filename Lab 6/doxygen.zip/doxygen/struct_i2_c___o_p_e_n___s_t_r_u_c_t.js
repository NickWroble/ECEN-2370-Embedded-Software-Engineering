var struct_i2_c___o_p_e_n___s_t_r_u_c_t =
[
    [ "clhr", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a21fe116060fe1e7dcefef7e0114b18bd", null ],
    [ "enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "freq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aacfad457f5366fa9265eb0a89e43f23b", null ],
    [ "master", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "out_SCL_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a3f938b3d911280441f6127d6b06415a6", null ],
    [ "out_SCL_route", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aed6fa83ceacbf094fdd2ad5748140827", null ],
    [ "out_SDA_en", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a30fbe217ad9157a6cbf4a464d5221e29", null ],
    [ "out_SDA_route", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a6b47ebf6ebab4f42501751935b88bd16", null ],
    [ "refFreq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a3b647a722e160769390ac1967b22b318", null ]
];