var struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f =
[
    [ "cbuf", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html#a9d443e36c08620b9ba9ecca59a84b872", null ],
    [ "read_ptr", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html#a439e2e5c347b4d54acc38f9b18bd6214", null ],
    [ "size", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html#ab2c6b258f02add8fdf4cfc7c371dd772", null ],
    [ "size_mask", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html#aa62a19df3e1b360fc848c4a8ff3b0116", null ],
    [ "write_ptr", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html#a2dfc42919a9acb43ebacd8cbe73abae2", null ]
];